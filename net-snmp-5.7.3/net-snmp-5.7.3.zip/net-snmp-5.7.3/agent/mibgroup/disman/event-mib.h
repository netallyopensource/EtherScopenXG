config_require(disman/event)

